import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import './addBarang.css';

const AddProduct = () => {
  const [productName, setProductName] = useState('');
  const [price, setPrice] = useState('');
  const [productImage, setProductImage] = useState(null);
  const navigate = useNavigate();

  const handleImageChange = (e) => {
    setProductImage(e.target.files[0]);
  };

  const handleAddProduct = async () => {
    try {
      if (!localStorage.getItem('userRole') || localStorage.getItem('userRole') !== 'admin') {
        console.error('Unauthorized access to add product.');
        return;
      }

      const formData = new FormData();
      formData.append('productName', productName);
      formData.append('price', price);
      formData.append('productImage', productImage);

      const token = localStorage.getItem('token');
      
      const response = await axios.post('http://localhost:5000/api/products', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
          'Authorization': token,
        },
      });

      console.log('Product added successfully:', response.data);
    } catch (error) {
      console.error('Error adding product:', error.message);
    }
  };

  return (
    <div className='out'> 
      <h2>Add Product</h2>
      <div className='in'>
        <div>
          <input type="text" placeholder='Product Name: ' value={productName} onChange={(e) => setProductName(e.target.value)} />
        </div>
        <div>
          <input type="text" placeholder='Price Product: ' value={price} onChange={(e) => setPrice(e.target.value)} />
        </div>
        <div>
          <input type="file" accept="image/*" onChange={handleImageChange} />
        </div>
        <div>
          <button onClick={handleAddProduct}>Add Product</button>
        </div>
      </div>
    </div>
  );
};

export default AddProduct;
