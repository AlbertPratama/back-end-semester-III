import React, { useEffect } from 'react';
import { useParams, useHistory } from 'react-router-dom';
import axios from 'axios';

const DeleteProductForm = () => {
  const { id } = useParams(); // Mengambil parameter id dari URL
  const history = useHistory();

  useEffect(() => {
    const deleteProduct = async () => {
      try {
        const token = localStorage.getItem('token');
        await axios.delete(`http://localhost:5000/api/products/${id}`, {
          headers: {
            Authorization: token,
          },
        });

        console.log('Product deleted successfully');
        history.push('/'); 
      } catch (error) {
        console.error('Error deleting product:', error.message);
      }
    };

    deleteProduct();
  }, [id, history]);

  return (
    <div>
      <h2>Delete Product</h2>
      <p>Deleting product...</p>
    </div>
  );
};

export default DeleteProductForm;
  