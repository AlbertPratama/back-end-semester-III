import React, { useState, useContext, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { ShopContext } from "../../context/shop-context";
import axios from "axios";
import "./edit.css"

const EditProductForm = () => {
  const { id } = useParams();
  const { products, setProducts } = useContext(ShopContext);
  const navigate = useNavigate();

  const [editedProduct, setEditedProduct] = useState({
    productName: "",
    price: 0,
    productImage: null,
  });

  useEffect(() => {
    // Fetch Data product berdasarkan ID
    const fetchProductData = async () => {
      try {
        const response = await axios.get(`http://localhost:5000/api/products/${id}`);
        setEditedProduct(response.data);
      } catch (error) {
        console.error("Error fetching product data:", error);
      }
    };

    fetchProductData();
  }, [id]);

  const handleEditProduct = async () => {
    try {
      const formData = new FormData();
      formData.append("productName", editedProduct.productName);
      formData.append("price", editedProduct.price);
      if (editedProduct.productImage) {
        formData.append("productImage", editedProduct.productImage);
      }
      const token = localStorage.getItem("token");

      const response = await axios.put(
        `http://localhost:5000/api/products/${id}`,
        formData,
        {
          headers: {
            "Content-Type": "multipart/form-data",
            Authorization: token,
          },
        }
      );

      console.log("Product edited successfully:", response.data);

      // Update Product di state lokal
      const updatedProducts = products.map((product) =>
        product.id === id ? response.data : product
      );
      setProducts(updatedProducts);

      // Navigate ke product
      navigate(`/product/${id}`);
    } catch (error) {
      console.error("Error editing product:", error.message);
    }
  };

  return (
    <div className='out'>
    <h2>Edit Product</h2>
    <div className='in'>
    <div>
      <input
        type="text"
        placeholder="Product Name"
        value={editedProduct.productName}
        onChange={(e) => setEditedProduct({ ...editedProduct, productName: e.target.value })}
      />
    </div>
    <div>
      <input
        type="text"
        value={editedProduct.price}
        onChange={(e) => setEditedProduct({ ...editedProduct, price: e.target.value })}
      />
    </div>
    <div>
      <input
        type="file"
        accept="image/*"
        onChange={(e) => setEditedProduct({ ...editedProduct, productImage: e.target.files[0] })}
      />
    </div>
    <div>
      <button onClick={handleEditProduct}>Save Changes</button>
    </div>
  </div>
</div>
  );
};

export default EditProductForm;
