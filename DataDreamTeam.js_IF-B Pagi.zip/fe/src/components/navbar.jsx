import React from "react";
import { Link } from "react-router-dom";
import { ShoppingCart } from "phosphor-react";
import DarkMode from './Toggle Theme/DarkMode';
import "./navbar.css";

export const Navbar = ({ token, handleLogout, userRole }) => {
  const isAdmin = userRole === 'admin';

  return (
    <div className="navbar">
      <div className="links">
        <Link to="/">Shop</Link>
        <Link to="/contact">Contact</Link>
        {isAdmin && <Link to="/add-product">Add Product</Link>}
        {!isAdmin && <Link to="/payment"><ShoppingCart size={32} /></Link>}
      </div>
      <button onClick={handleLogout}>Logout</button>
      <DarkMode />
    </div>
  );
};
