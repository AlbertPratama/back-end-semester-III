// app.js
import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Navbar } from './components/navbar.jsx';
import Shop from './pages/shop/shop.jsx';
import { Contact } from './pages/contact/contact.jsx';
import { Cart } from './pages/cart/cart.jsx';
import Payment from './pages/cart/payment.jsx';
import AddProduct from './components/crud/addBarang.jsx';
import EditProductForm from './components/crud/edit.jsx';
import { ShopContextProvider } from './context/shop-context.jsx';
import { ThemeProvider } from './context/theme-context.js';
import Login from './pages/Login/Login.js';
import { ProductContextProvider } from './context/productsController.jsx';
import './App.css';

function App() {
  const [token, setToken] = useState('');
  const [userRole, setUserRole] = useState('');

  useEffect(() => {
    const storedToken = localStorage.getItem('token');
    const storedUserRole = localStorage.getItem('userRole');
    if (storedToken && storedUserRole) {
      setToken(storedToken);
      setUserRole(storedUserRole);
    }
  }, []);

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('userRole');
    setToken('');
    setUserRole('');
  };

  return (
    <div className="App">
      <ThemeProvider>
        <ProductContextProvider>
          <ShopContextProvider userRole={userRole}>
            <Router>
              <Navbar token={token} handleLogout={handleLogout} userRole={userRole} />
              <Routes>
              
              <Route
                  path="/"
                  element={token ? (
                    userRole === 'admin' ? <Navigate to="/admin/products" /> : <Shop />
                  ) : (
                    <Login setToken={setToken} setUserRole={setUserRole} />
                  )}
                />

                <Route
                  path="/login"
                  element={token ? <Navigate to="/" /> : <Login setToken={setToken} setUserRole={setUserRole} />}
                />

                <Route 
                  path="/add-product" 
                  element={userRole === 'admin' ? <AddProduct /> : <Navigate to="/login" />}
                />

                <Route
                  path="/edit-product/:id"
                  element={userRole === 'admin' ? <EditProductForm /> : <Navigate to="/login" />}
                /> 

                <Route
                  path="/admin/products"
                  element={token && userRole === 'admin' ? <Shop /> : <Navigate to="/login" />}
                />

                <Route
                  path="/contact"
                  element={token ? <Contact /> : <Navigate to="/login" />}
                />

                <Route
                  path="/cart"
                  element={token ? <Cart /> : <Navigate to="/login" />}
                />

                <Route
                  path="/payment"
                  element={token ? <Payment userRole={userRole} /> : <Navigate to="/login" />}
                />
              </Routes>
            </Router>
          </ShopContextProvider>
        </ProductContextProvider>
      </ThemeProvider>
    </div>
  );
}

export default App;
