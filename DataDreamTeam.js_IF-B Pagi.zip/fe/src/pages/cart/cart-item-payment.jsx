import React from "react";
import axios from "axios";

const CartItem = (props) => {
  const { id, productName, price, productImage, quantity } = props.data;

  const handleDeleteItem = async () => {
    try {
      await axios.delete(`http://localhost:5000/data_pembelian/${id}`);
      console.log(`Item with ID ${id} deleted successfully.`);
    } catch (error) {
      console.error("Error deleting item:", error);
    }
  };

  return (
    <div className="cartItem">
      <img src={`http://localhost:5000/image/${productImage}`} alt={productName} />
      <div className="description">
        <p>
          <b>{productName}</b>
        </p>
        <p> Price: ${price}</p>

        <div className="countHandler">
          <p>Jumlah: {quantity}</p>
        </div>
      </div>
    </div>
  );
};

export default CartItem;
