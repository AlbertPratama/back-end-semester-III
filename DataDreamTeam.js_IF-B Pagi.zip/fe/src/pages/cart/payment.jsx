
import React, { useEffect, useState } from "react";
import { useTheme } from "../../context/theme-context.js";
import  CartItem  from "./cart-item-payment.jsx";
import './payment.css';
import axios from "axios";

const Payment = ({ isAdmin }) => {
  const { isDarkMode } = useTheme();
  const [dataPembelian, setDataPembelian] = useState([]);

  useEffect(() => {
    if (!isAdmin) {
      axios.get("http://localhost:5000/data_pembelian")
        .then((response) => {
          console.log('Response Data Pembelian:', response.data);
          const mergedDataPembelian = response.data.flat();
          setDataPembelian(mergedDataPembelian);
        })
        .catch((error) => {
          console.error("Terjadi kesalahan saat mengambil data pembelian:", error);
        });
    }
  }, [isAdmin]);

return (
  <div className={`payment ${isDarkMode ? "dark" : "light"}`}>
    {isAdmin ? (
      <h1>Admins do not have access to this page.</h1>
    ) : (
      <>
        <h1>Cart</h1>
        {dataPembelian.length > 0 ? (
          <div className="okay">
            {dataPembelian.map((item) => {
              if (item && item.id) {
                return <CartItem key={item.id} data={item} />;
              }
              return null;
            })}
          </div>
        ) : (
          <h1 id="Todo">Your Item Is Empty</h1>
        )}
      </>
    )}
  </div>
);

};

export default Payment;
