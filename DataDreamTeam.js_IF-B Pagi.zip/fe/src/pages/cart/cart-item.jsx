import React, { useContext } from "react";
import axios from "axios";
import { ShopContext } from "../../context/shop-context";

const CartItem = (props) => {
  const { id, productName, price, quantity, productImage } = props.data;
  const { removeFromCart } = useContext(ShopContext);

  const handleDeleteItem = async () => {
    try {
      await removeFromCart(id);
      console.log(`Item with ID ${id} deleted successfully.`);
    } catch (error) {
      console.error("Error deleting item:", error);
    }
  };

  return (
    <div className="cartItem">
      {productImage && (
        <img src={`http://localhost:5000/image/${productImage}`} alt={productName} />
      )}
      <div className="description">
        <p>
          <b>{productName}</b>
        </p>
        <p> Price: ${price}</p>

        <div className="countHandler">
          <p>Jumlah: {quantity}</p>
        </div>
        <button id="button" onClick={handleDeleteItem}>
          Delete item
        </button>
      </div>
    </div>
  );
};

export default CartItem;
