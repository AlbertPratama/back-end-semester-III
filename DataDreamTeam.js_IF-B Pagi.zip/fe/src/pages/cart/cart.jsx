import React, { useContext, useEffect, useState } from "react";
import { ShopContext } from "../../context/shop-context";
import CartItem from "./cart-item.jsx";
import { useNavigate } from "react-router-dom";
import { useTheme } from "../../context/theme-context";
import axios from 'axios';

export const Cart = () => {
  const { cartItems, getTotalCartAmount, checkout } = useContext(ShopContext);
  const totalAmount = getTotalCartAmount();
  const { isDarkMode } = useTheme();
  const navigate = useNavigate();

  const [products, setProducts] = useState([]);

  useEffect(() => {
    // Fetch data barang dari server saat komponen dimuat
    axios.get("http://localhost:5000/api/products")
      .then((response) => {
        setProducts(response.data);
      })
      .catch((error) => {
        console.error("Error mengambil data barang:", error);
      });
  }, []); 

  const handleCheckout = async () => {
    try {
      await checkout();
      navigate("/payment");
    } catch (error) {
      console.error("Error during checkout:", error);
    }
  };

  return (
    <div className={`cart ${isDarkMode ? "dark" : "light"}`}>
      <div>
        <h1>Your Cart Items</h1>
      </div>

      <div className="cart">
        {Object.keys(cartItems).map((itemId) => {
          const product = products.find((p) => p.id === Number(itemId));

          if (product) {
            return <CartItem key={itemId} data={{ ...product, quantity: cartItems[itemId] }} />;
          }

          return null;
        })}
      </div>

      {totalAmount > 0 ? (
        <div className="checkout">
          <p> Subtotal: ${totalAmount} </p>
          <button onClick={() => navigate("/")}> Continue Shopping </button>
          <button onClick={handleCheckout}> Checkout </button>
        </div>
      ) : (
        <div id="Todo">
          <h1> Your Shopping Cart is Empty</h1>
        </div>
      )}
    </div>
  );
};
