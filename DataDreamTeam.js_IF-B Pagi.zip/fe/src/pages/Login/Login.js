// Login.js
import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import './Login.css';

const Login = ({ setToken, setUserRole }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  const handleLogin = async () => {
    try {
      const response = await axios.post('http://localhost:5000/api/login', { username, password });
      const token = response.data.token;
  
      localStorage.setItem('token', token);
      setToken(token);
  
      const userRole = response.data.role;
      localStorage.setItem('userRole', userRole); // Menyimpan userRole ke localStorage
      setUserRole(userRole);
      console.log('Token:', token);
      console.log('User Role:', userRole);
  
      navigate('/');
    } catch (error) {
      console.error('Login error:', error.message);
      // Handle login error
    }
  };

  return (
    <div className="login-box">
      <h2>Login</h2>
      <form>
        <div className="user-box">
          <input
            type="text"
            onChange={(e) => setUsername(e.target.value)}
            required
          />
          <label>Username</label>
        </div>

        <div className="user-box">
          <input
            type="password"
            onChange={(e) => setPassword(e.target.value)}
            required
          />
          <label>Password</label>
        </div>

        <button type="button" onClick={handleLogin}>
          <span></span>
          <span></span>
          <span></span>
          <span></span>
          Sign In
        </button>
      </form>
    </div>
  );
};

export default Login;
