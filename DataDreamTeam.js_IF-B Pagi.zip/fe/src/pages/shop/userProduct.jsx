// ProductUser.jsx
import React, { useContext } from "react";
import { ShopContext } from "../../context/shop-context";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const ProductUser = (props) => {
  const { id, productName, price, productImage } = props.data;
  const { addToCart, cartItems } = useContext(ShopContext);
  const navigate = useNavigate();

  const handleAddToCart = async () => {
    try {
      if (!id || !productName || !price || !productImage) {
        console.error("Invalid product data");
        return;
      }

      await addToCart(id, () => {
        console.log("Navigasi ke halaman keranjang");
      });

      const response = await axios.post("http://localhost:5000/data_pembelian", {
        id,
        productName,
        price,
        productImage,
        quantity: 1,
      });

      console.log("Data pembelian berhasil ditambahkan:", response.data);
    } catch (error) {
      console.error("Error handling add to cart:", error);
    }
  };

  return (
    <div className="product">
      <img src={`http://localhost:5000/image/${productImage}`} alt={productName} />
      <div className="description">
        <p>
          <b>{productName}</b>
        </p>
        <p>${price}</p>
      </div>
      
      <button className="addToCartBttn" onClick={handleAddToCart}>
        Add To Cart {cartItems[id] > 0 && <> ({cartItems[id]})</>}
      </button>
    </div>
  );
};

export default ProductUser;
