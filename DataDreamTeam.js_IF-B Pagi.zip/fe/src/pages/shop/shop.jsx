import React, { useContext, useEffect, useState } from "react";
import ProductUser from "./userProduct";
import ProductAdmin from "./adminProduct";
import { useTheme } from "../../context/theme-context";
import { ProductContext } from '../../context/productsController';
import "./shop.css";

const Shop = () => {
  const { products } = useContext(ProductContext);
  const { isDarkMode } = useTheme();
  const [userRole, setUserRole] = useState(localStorage.getItem("userRole"));

  useEffect(() => {
    console.log("User Role:", userRole);
  }, [userRole]);

  return (
    <div className={`shop ${isDarkMode ? "dark" : "light"}`}>
      <div className="shopTitle"></div>
      <div className="products">
        {products.map((product, id) => (
          <div key={id}>
            {userRole === 'admin' ? (
              <ProductAdmin data={product} />
            ) : (
              <ProductUser data={product} />
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default Shop;
