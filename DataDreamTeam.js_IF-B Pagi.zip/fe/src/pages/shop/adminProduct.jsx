import React, { useContext } from "react";
import { ShopContext } from "../../context/shop-context";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import "./adminProduct.css"

const ProductAdmin = (props) => {
  const { id, productName, price, productImage } = props.data;
  const { addToCart, cartItems } = useContext(ShopContext);
  const navigate = useNavigate();

  const handleEditProduct = () => {
    console.log('Editing product:', id);
    navigate(`/edit-product/${id}`);
  };

  const handleDeleteProduct = async () => {
    console.log('Deleting product:', id);
    try {
      const token = localStorage.getItem("token");

      await axios.delete(`http://localhost:5000/api/products/${id}`, {
        headers: {
          Authorization: token,
        },
      });

      console.log("ProductAdmin deleted successfully");

      navigate('/');
    } catch (error) {
      console.error("Error deleting product:", error.message);
    }
  };

  return (
    <div className="product">
      <img src={`http://localhost:5000/image/${productImage}`} alt={productName} />
      <div className="description">
        <p>
          <b>{productName}</b>
        </p>
        <p>${price}</p>
      </div>

      {localStorage.getItem("userRole") === "admin" && (
        <div>
          <button onClick={handleEditProduct}>Edit Produk</button>
          <button onClick={handleDeleteProduct}>Hapus Produk</button>
        </div>
      )}
    </div>
  );
};

export default ProductAdmin;
