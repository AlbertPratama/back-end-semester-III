import { createContext, useState, useEffect } from "react";
import axios from "axios";

export const ShopContext = createContext(null);

export const ShopContextProvider = ({ children }) => {
  const [cartItems, setCartItems] = useState({});
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    // Cek apakah user adalah admin 
    const userRole = localStorage.getItem("userRole");
    setIsAdmin(userRole === "admin");
  }, []);

  useEffect(() => {
    axios.get("http://localhost:5000/data_pembelian")
      .then((response) => {
        setCartItems(response.data);
      })
      .catch((error) => {
        console.error("Error mengambil data keranjang:", error);
      });
  }, []);

  const addToCart = (itemId, navigateCallback) => {
    axios.post("http://localhost:5000/data_pembelian", { itemId })
      .then((response) => {
        setCartItems(response.data);

        // callback untuk menavigasi
        if (navigateCallback) {
          navigateCallback("/cart");
        }
      })
      .catch((error) => {
        console.error(`Error menambah item ke keranjang:`, error);
      });
  };

  const getTotalCartAmount = async () => {
    let totalAmount = 0;

    for (const itemId in cartItems) {
      if (cartItems[itemId] > 0) {
        try {
          const response = await axios.get(`http://localhost:5000/data_pembelian/${itemId}`);
          const itemInfo = response.data;
          totalAmount += cartItems[itemId] * itemInfo.price;
        } catch (error) {
          console.error(`Error mengambil data produk ${itemId}:`, error);
        }
      }
    }
    return totalAmount;
  };


  const removeFromCart = (itemId) => {
    axios.delete(`http://localhost:5000/data_pembelian/${itemId}`)
      .then((response) => {
        setCartItems(response.data);
      })
      .catch((error) => {
        console.error(`Error menghapus item dari keranjang:`, error);
      });
  };

  const updateCartItemCount = (newAmount, itemId) => {
    axios.put(`http://localhost:5000/data_pembelian/${itemId}`, { newAmount })
      .then((response) => {
        setCartItems(response.data);
      })
      .catch((error) => {
        console.error(`Error memperbarui jumlah item di keranjang:`, error);
      });
  };

  const checkout = () => {
    axios.post("http://localhost:5000/checkout")
      .then((response) => {
        setCartItems(response.data);
      })
      .catch((error) => {
        console.error(`Error melakukan proses checkout:`, error);
      });
  };

  const contextValue = {
    cartItems,
    addToCart,
    getTotalCartAmount,
    isAdmin,
    setIsAdmin,
  };

  return (
    <ShopContext.Provider value={contextValue}>
      {children}
    </ShopContext.Provider>
  );
};
