import express from 'express';
import mysql2 from 'mysql2';
import bodyParser from 'body-parser';
import jwt from 'jsonwebtoken';
import cors from 'cors';
import multer from 'multer';
import path from 'path';
import { fileURLToPath } from 'url';

const conn = mysql2.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'Mudahdi1ng4t',
  database: 'dataset',
  port: 3306
});

const app = express();
const PORT = 5000;
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

app.use(bodyParser.json());
app.use(cors());
app.use('/image', express.static(path.join(__dirname, 'public', 'image')));


// Penanganan menandatangani token
const signJwt = (payload) => {
  try {
    const token = jwt.sign(payload, 'secret-key');
    return token;
  } catch (error) {
    console.error('Error creating JWT:', error);
    throw error;
  }
};

const verifyAdmin = (req, res, next) => {
  const token = req.header('Authorization');

  if (!token) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  try {
    const decoded = jwt.verify(token, 'secret-key');

    if (decoded.role !== 'admin') {
      return res.status(403).json({ error: 'Forbidden - Admin access required' });
    }

    next();
  } catch (error) {
    res.status(401).json({ error: 'Invalid token' });
  }
};

const saveUser = async (username, password, role) => {
  try {
    const sql = 'INSERT INTO users (username, password, role) VALUES (?, ?, ?)';
    await conn.promise().execute(sql, [username, password, role]);
  } catch (error) {
    console.error('Error saving user:', error);
    throw error;
  }
};

// Mengecek user di database
const checkUser = async (username, password) => {
  try {
    const sql = 'SELECT * FROM users WHERE username = ? AND password = ?';
    const [rows] = await conn.promise().execute(sql, [username, password]);

    if (rows.length > 0) {
      return rows[0];
    } else {
      return null;
    }
  } catch (error) {
    console.error('Error checking user:', error);
    throw error;
  }
};

app.post('/api/login', async (req, res) => {
  const { username, password } = req.body;

  try {
    const user = await checkUser(username, password);

    if (user) {
      const token = signJwt({ username, role: user.role });
      res.json({ token, role: user.role }); 
    } else {
      res.status(401).json({ error: 'Invalid username or password' });
    }
  } catch (error) {
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

// Multer Configuration
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'public/image'); 
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + '-' + file.originalname); 
  },
});

const upload = multer({ storage: storage });

// ini bagian CRUD Admin 
app.get('/api/products/:id', (req, res) => {
  try {
    let productId = req.params.id;

    let sql = 'SELECT * FROM products WHERE id = ?';
    conn.query(sql, [productId], (err, result) => {
      if (err) {
        console.error('Error fetching product:', err);
        return res.status(500).json({ error: 'Internal Server Error' });
      }

      if (result.length === 0) {
        return res.status(404).json({ error: 'Product not found' });
      }

      // Mengembalikan path gambar
      const product = result[0];
      const imagePath = product.productImage ? `http://localhost:5000/image/${product.productImage}` : null;

      return res.status(200).json({ ...product, productImage: imagePath });
    });
  } catch (error) {
    console.error('Unexpected error fetching product:', error);
    return res.status(500).json({ error: 'Internal Server Error' });
  }
});

app.post('/api/products', verifyAdmin,upload.single('productImage'), (req, res) => {
  try {
    const productName = req.body.productName;
    const price = req.body.price;
    const productImage = req.file ? req.file.filename : null;

    if (!productName || !price) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    const sql = 'INSERT INTO products (productName, price, productImage) VALUES (?, ?, ?)';
    conn.query(sql, [productName, price, productImage], (err, result) => {
      if (err) {
        console.error('Error adding product:', err);
        return res.status(500).json({ error: 'Internal Server Error' });
      }

      // Mengembalikan path gambar
      const imagePath = productImage ? `http://localhost:5000/image/${productImage}` : null;

      return res.status(200).json({ productName, price, productImage: imagePath });
    });
  } catch (error) {
    console.error('Unexpected error adding product:', error);
    return res.status(500).json({ error: 'Internal Server Error' });
  }
});

app.put('/api/products/:id', verifyAdmin, upload.single('productImage'), (req, res) => {
  try {
    let productId = req.params.id;
    let productName = req.body.productName;
    let price = req.body.price;
    let productImage = req.file ? req.file.filename : null;

    let sql;
    let params;

    if (productImage) {
      // Jika ada gambar produk baru, perbarui productName, price, dan productImage
      sql = 'update products set productName = ?, price = ?, productImage = ? where id = ?';
      params = [productName, price, productImage, productId];
    } else {
      // Jika tidak ada gambar produk baru, hanya perbarui productName dan price
      sql = 'update products set productName = ?, price = ? where id = ?';
      params = [productName, price, productId];
    }

    conn.query(sql, params, (err, result) => {
      if (err) {
        console.error('Error updating product:', err);
        return res.status(500).json({ error: 'Internal Server Error' });
      }

      // Mengembalikan path gambar
      const imagePath = productImage ? `http://localhost:5000/image/${productImage}` : null;

      return res.status(200).json({ productName, price, productImage: imagePath });
    });
  } catch (error) {
    console.error('Unexpected error updating product:', error);
    return res.status(500).json({ error: 'Internal Server Error' });
  }
});


app.delete('/api/products/:id', verifyAdmin, (req, res) => {
  try {
    let productId = req.params.id;

    let deleteSql = 'delete from products where id = ?';
    conn.query(deleteSql, [productId], (deleteErr, deleteResult) => {
      if (deleteErr) {
        console.error('Error deleting product:', deleteErr);
        return res.status(500).json({ error: 'Internal Server Error' });
      }

      if (deleteResult.affectedRows === 0) {
        return res.status(404).json({ error: 'Product not found' });
      }

      return res.status(200).json(deleteResult);
    });
  } catch (error) {
    console.error('Unexpected error deleting product:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});


// User data 
let dataPembelianList = [];

app.get('/data_pembelian', (req, res) => {
  res.json(dataPembelianList);
});

app.post('/checkout', (req, res) => {
  const dataPembelian = req.body.dataPembelian;
  // Proses checkout di sini
  console.log('Data Pembelian untuk Checkout:', dataPembelian);
  res.json({ message: 'Checkout berhasil' });
});

app.post('/data_pembelian', (req, res) => {
  const { id, productName, price, productImage, quantity } = req.body;

  const newItem = {
    id,
    productName,
    price,
    productImage,
    quantity,
  };

  // Menambahkan item baru ke data pembelian
  dataPembelianList.push(newItem);

  console.log('Data Pembelian API:', newItem);
  res.status(200).json({ message: 'Data Pembelian berhasil diterima' });
});

app.delete('/data_pembelian/:id', (req, res) => {
  const ida = parseInt(req.params.id, 10);
  dataPembelianList = dataPembelianList.filter(item => item.id !== ida);
  console.log(`Berhasil menghapus item dengan ID ${ida}`);
});

app.get('/api/products', (req, res) => {
  let sql = 'select * from products';
  conn.query(sql, (err, result) => {
    if (err) return res.json('Error');
    return res.json(result);
  });
});

app.get('/home', (req, res) => {
  let sql = "select * from products"
  conn.query(sql, (err, result) => {
      if (err) return res.json("Error")
      return res.json(result)
  })
});

app.post('/api/reset_id', (req, res) => {
  conn.beginTransaction((err) => {
      if (err) throw err;

      conn.query('set @autoid := 0', (error, results) => {
          if (error) {
              return conn.rollback(() => {
                  throw error;
              });
          }

          conn.query('update products set id = @autoid := (@autoid + 1)', (err, results) => {
              if (err) {
                  return conn.rollback(() => {
                      throw err;
                  });
              }

              conn.query('alter table products AUTO_INCREMENT = 1', (error, results) => {
                  if (error) {
                      return conn.rollback(() => {
                          throw error;
                      });
                  }

                  conn.commit((err) => {
                      if (err) {
                          return conn.rollback(() => {
                              throw err;
                          });
                      }
                      console.log('Auto-increment reset successfully.');
                      res.send('Auto-increment reset successfully.');
                  });
              });
          });
      });
  });
});

app.delete('/api/delete/:id', (req, res) => {
  const productId = req.params.id;

  const deleteSql = `DELETE FROM products WHERE id = ${productId}`;
  conn.query(deleteSql, [productId], (deleteErr, deleteResult) => {
      if (deleteErr) {
          console.error('Error deleting data:', deleteErr);
          return res.status(500).json({ error: 'Internal Server Error' });
      }

      if (deleteResult.affectedRows === 0) {
          return res.status(404).json({ error: 'Data not found' });
      }

      return res.status(200).json(deleteResult);
  });
});

app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
