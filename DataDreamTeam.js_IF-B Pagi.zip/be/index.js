const express = require('express');
const app = express();
const port = 3000;

app.set('view engine', 'ejs');

app.get('/', (req, res) => {
  res.render('index', { message: 'Hello World' });
});

app.listen(port, () => {
  console.log(`Server berjalan di http://localhost:${port}`);
});



// const express = require('express')
// const app = express()
// const port = 3001
// const cors = require('cors')

// app.use(express.urlencoded({ extended: true }))
// app.use(express.json());

// app.use(cors())

// // app.get("/", cors(), async (req, res) => {
// //     res.send('This is Working')
// // })

// // app.get('/home', cors(), async (req, res) => {
// //     res.send('This data From Home')
// // })

// // app.post("/post_name", async(req, res) => {
// //     let {data} = req.body
// //     const datakom = data
// //     console.log(datakom)
// // })

// let postData = {}; // Membuat objek untuk menyimpan data dari permintaan POST

// app.post("/post_name", (req, res) => {
//     let { data } = req.body;
//     console.log(data);
//     postData.data = data;
//     res.send(`Data berhasil diterima di server.`);
// });

// app.get("/post_name", async (req, res) => {
//     if (postData.data) {
//         console.log("Nilai postData:", postData.data);
//         // res.send(`<h1>This data From Home: ${postData.data}</h1>`);
//         res.send(postData.data)
//     } else {
//         console.log(postData.data)
//         res.send(`<h1>No data available</h1>`);
//     }
// });


// // app.post("/post_name", (req, res) => {
// //   let { data } = req.body;
// //   console.log(data); // Mencetak data yang diterima dari front-end ke konsol
// //   res.send(`Data berhasil diterima di server.`); // Anda bisa mengirimkan respons balik jika perlu

// // });

// // app.get("/post_name", async(req, res) => {
// //     res.send(`<h1>This data From Home</h1>`)
// // })

// // app.post("/post_name", async(req, res) => {
// //     let {name} = req.body
// //     const datakom = name**2
// //     console.log(`Hasil kuadrat dari ${name} adalah ${datakom}`)
// // })

// app.listen(port, () => {
//     console.log(`Listening at http://localhost:${port}`)
// })